This is a demo GTFS feed for gtfs.guru. It is not real transit data.

It contains deliberate mistakes so the validator has something to report:

  * stops.txt   stop3 has no stop_name
  * stops.txt   stop5 appears twice with different names
  * stops.txt   stop8 is never served by any trip
  * stops.txt   stop4 repeats its name in stop_desc
  * trips.txt   trip4 uses a service_id that no calendar defines
  * stop_times  trip2 departs stop2 three minutes before it arrives
  * stop_times  trip5 reaches its second stop ten minutes before its first
  * trips.txt   trip2 is the return trip but reuses the outbound shape
  * routes.txt  route2 prints yellow text on a yellow background

Do not use this feed for anything other than trying out a validator.
